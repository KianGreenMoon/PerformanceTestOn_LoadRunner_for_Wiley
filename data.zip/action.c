Action()
{

	lr_start_transaction("1_transaction");

	web_add_cookie("SID=Xq2GlUd4QNkYTyRM6IKX4JkApIQZB41g; DOMAIN=test.youplace.net");

	web_url("test.youplace.net", 
		"URL=http://test.youplace.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	/* Request with GET method to URL "http://test.youplace.net/favicon.ico" failed during recording. Server response : 404*/

	web_link("Start test", 
		"Text=Start test", 
		"Snapshot=t30.inf", 
		LAST);

	/* Request with GET method to URL "http://test.youplace.net/favicon.ico" failed during recording. Server response : 404*/

	lr_end_transaction("1_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("2_transaction");

	web_submit_form("1", 
		"Snapshot=t31.inf", 
		ITEMDATA, 
		"Name=5smsXnJohOdKKLfN", "Value=test", ENDITEM, 
		"Name=92tKCQNjy4GBP7L6", "Value=YfUzUCgRDFUq5OVE", ENDITEM, 
		"Name=iZeL2hinIblkpKs8", "Value=ahSTKU574gWoC", ENDITEM, 
		"Name=sbUQIxUGvfmA5zya", "Value=test", ENDITEM, 
		LAST);

	lr_end_transaction("2_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("3_transaction");

	web_submit_form("2", 
		"Snapshot=t32.inf", 
		ITEMDATA, 
		"Name=gPaAIbsPHAESmOA8", "Value=Bn8koaTtCm0mA", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("4_transaction");

	web_submit_form("3", 
		"Snapshot=t33.inf", 
		ITEMDATA, 
		"Name=q8WB4Ako6o8G8i2N", "Value=RG87IGI43iTFk", ENDITEM, 
		"Name=QoBCiAQsPupQb4a1", "Value=test", ENDITEM, 
		"Name=ebamvnLP1hvqsQkg", "Value=5zX17DLg2n5FfYu", ENDITEM, 
		LAST);

	lr_end_transaction("4_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("5_transaction");

	web_submit_form("4", 
		"Snapshot=t34.inf", 
		ITEMDATA, 
		"Name=V4TruF96qY8EM5bi", "Value=UqzpjVxneBGYhu", ENDITEM, 
		"Name=KupSH765P6HOUq4h", "Value=test", ENDITEM, 
		"Name=WotClr2UAG2y9NG4", "Value=65qcmL5HHN2C9q3", ENDITEM, 
		"Name=XSvHE0wPXIrmLQfi", "Value=test", ENDITEM, 
		LAST);

	lr_end_transaction("5_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("refresh");

	web_url("5", 
		"URL=http://test.youplace.net/question/5", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://test.youplace.net/question/4", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("refresh",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("error");

	/* Request with POST method to URL "http://test.youplace.net/question/5" failed during recording. Server response : 406*/

	/* Request with POST method to URL "http://test.youplace.net/question/5" failed during recording. Server response : 406*/

	lr_end_transaction("error",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("6_transaction");

	web_submit_form("5_2", 
		"Snapshot=t36.inf", 
		ITEMDATA, 
		"Name=PkMkxr1CwGXq3aOp", "Value=e7meKLanQplCRrGY", ENDITEM, 
		"Name=q8SKwjWKXn27kzuH", "Value=3UZso9dHrQgl0E", ENDITEM, 
		LAST);

	lr_end_transaction("6_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("7_transaction");

	web_submit_form("6", 
		"Snapshot=t37.inf", 
		ITEMDATA, 
		"Name=sV4i537x9zvKcFxG", "Value=test", ENDITEM, 
		"Name=p0XSISBJRc40et2c", "Value=test", ENDITEM, 
		"Name=m5UHJPs9CdgTYILs", "Value=test", ENDITEM, 
		"Name=qmuo6Ncy0CtFJc5Q", "Value=dXeWGN9Xm60Eo0W", ENDITEM, 
		LAST);

	lr_end_transaction("7_transaction",LR_AUTO);

	lr_think_time(3);

	lr_start_transaction("8_transaction");

	web_url("7", 
		"URL=http://test.youplace.net/question/7", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://test.youplace.net/question/6", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_form("7_2", 
		"Snapshot=t39.inf", 
		ITEMDATA, 
		"Name=nBPRbgAFvqGVuVnl", "Value=SZ8haOt2d2oN4", ENDITEM, 
		"Name=LOcFzyNbtdxWGHGf", "Value=test", ENDITEM, 
		LAST);

	lr_end_transaction("8_transaction",LR_AUTO);

	lr_think_time(3);

	return 0;
}